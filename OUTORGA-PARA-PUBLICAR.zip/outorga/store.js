const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const bcrypt = require("bcryptjs");

const DATA_DIR = path.join(__dirname, "data");
const FILE = path.join(DATA_DIR, "store.json");
const UPLOADS = path.join(DATA_DIR, "uploads");

function ensureDirs() {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  fs.mkdirSync(UPLOADS, { recursive: true });
}

function empty() {
  return { users: [], procuracoes: [] };
}

class Store {
  constructor() {
    ensureDirs();
    this.data = empty();
    this.load();
  }

  load() {
    try {
      if (fs.existsSync(FILE)) {
        this.data = JSON.parse(fs.readFileSync(FILE, "utf8"));
        this.data.users ||= [];
        this.data.procuracoes ||= [];
        this.data.users.forEach((u) => {
          if (u.mustChangePassword === undefined) u.mustChangePassword = true;
        });
        this.data.procuracoes.forEach((p) => {
          if (!p.pin) p.pin = genPin();
          p.historico ||= [{ em: p.createdAt, fato: "Mandato criado" }];
        });
      }
    } catch {
      this.data = empty();
    }
  }

  save() {
    const tmp = FILE + ".tmp";
    fs.writeFileSync(tmp, JSON.stringify(this.data, null, 2));
    fs.renameSync(tmp, FILE);
  }

  uid() {
    return crypto.randomBytes(12).toString("hex");
  }

  token() {
    return crypto.randomBytes(9).toString("base64url");
  }

  codigo() {
    const n =
      this.data.procuracoes.reduce((max, p) => {
        const k = parseInt(String(p.codigo || "").replace(/\D/g, ""), 10);
        return Number.isFinite(k) && k > max ? k : max;
      }, 0) + 1;
    return "OUT-" + String(n).padStart(5, "0");
  }

  findUserByEmail(email) {
    return this.data.users.find(
      (u) => u.email.toLowerCase() === String(email || "").toLowerCase()
    );
  }

  findUser(id) {
    return this.data.users.find((u) => u.id === id);
  }

  createUser(payload) {
    if (this.findUserByEmail(payload.email)) {
      const err = new Error("E-mail já cadastrado");
      err.status = 409;
      throw err;
    }
    const user = {
      id: this.uid(),
      createdAt: new Date().toISOString(),
      email: payload.email.trim().toLowerCase(),
      passwordHash: bcrypt.hashSync(payload.password, 10),
      nome: payload.nome.trim(),
      cpf: payload.cpf || "",
      rg: payload.rg || "",
      nacionalidade: payload.nacionalidade || "brasileiro(a)",
      estadoCivil: payload.estadoCivil || "",
      profissao: payload.profissao || "Despachante documentalista",
      empresa: payload.empresa || "",
      registro: payload.registro || "",
      telefone: payload.telefone || "",
      cep: payload.cep || "",
      endereco: payload.endereco || "",
      numero: payload.numero || "",
      bairro: payload.bairro || "",
      cidade: payload.cidade || "",
      uf: payload.uf || "",
      mustChangePassword: !!payload.mustChangePassword,
      passwordChangedAt: null,
    };
    this.data.users.push(user);
    this.save();
    return this.publicUser(user);
  }

  updateUser(id, patch) {
    const user = this.findUser(id);
    if (!user) return null;
    const fields = [
      "nome",
      "cpf",
      "rg",
      "nacionalidade",
      "estadoCivil",
      "profissao",
      "empresa",
      "registro",
      "telefone",
      "cep",
      "endereco",
      "numero",
      "bairro",
      "cidade",
      "uf",
    ];
    for (const f of fields) {
      if (patch[f] !== undefined) user[f] = patch[f];
    }
    if (patch.email) user.email = patch.email.trim().toLowerCase();
    this.save();
    return this.publicUser(user);
  }

  changePassword(id, atual, nova) {
    const user = this.findUser(id);
    if (!user) return null;
    if (!bcrypt.compareSync(atual || "", user.passwordHash)) {
      const err = new Error("Senha atual incorreta");
      err.status = 400;
      throw err;
    }
    const msg = strongPass(nova);
    if (msg) {
      const err = new Error(msg);
      err.status = 400;
      throw err;
    }
    if (bcrypt.compareSync(nova, user.passwordHash)) {
      const err = new Error("A nova senha precisa ser diferente");
      err.status = 400;
      throw err;
    }
    user.passwordHash = bcrypt.hashSync(nova, 10);
    user.mustChangePassword = false;
    user.passwordChangedAt = new Date().toISOString();
    this.save();
    return this.publicUser(user);
  }

  publicUser(user) {
    if (!user) return null;
    const { passwordHash, ...rest } = user;
    return rest;
  }

  listProcuracoes(userId) {
    return this.data.procuracoes
      .filter((p) => p.userId === userId)
      .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  }

  findProcuracao(id, userId) {
    const p = this.data.procuracoes.find((x) => x.id === id);
    if (!p) return null;
    if (userId && p.userId !== userId) return null;
    return p;
  }

  findByToken(token) {
    return this.data.procuracoes.find((p) => p.token === token) || null;
  }

  findByCodigo(codigo) {
    return (
      this.data.procuracoes.find(
        (p) => p.codigo && p.codigo.toUpperCase() === String(codigo).toUpperCase()
      ) || null
    );
  }

  createProcuracao(userId, body) {
    const p = {
      id: this.uid(),
      userId,
      token: this.token(),
      codigo: this.codigo(),
      status: "aguardando",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      signedAt: null,
      validadeDias: Number(body.validadeDias) || 365,
      substabelecer: !!body.substabelecer,
      whatsapp: body.whatsapp || "",
      observacoes: body.observacoes || "",
      pin: String(body.pin || genPin()).replace(/\D/g, "").slice(0, 4) || genPin(),
      historico: [{ em: new Date().toISOString(), fato: "Mandato criado" }],
      cliente: {
        nome: body.cliente?.nome || "",
        cpf: body.cliente?.cpf || "",
        rg: body.cliente?.rg || "",
        orgaoRg: body.cliente?.orgaoRg || "",
        nacionalidade: body.cliente?.nacionalidade || "brasileiro(a)",
        estadoCivil: body.cliente?.estadoCivil || "",
        profissao: body.cliente?.profissao || "",
        email: body.cliente?.email || "",
        telefone: body.cliente?.telefone || body.whatsapp || "",
        cep: body.cliente?.cep || "",
        endereco: body.cliente?.endereco || "",
        numero: body.cliente?.numero || "",
        complemento: body.cliente?.complemento || "",
        bairro: body.cliente?.bairro || "",
        cidade: body.cliente?.cidade || "",
        uf: body.cliente?.uf || "",
      },
      veiculo: {
        placa: (body.veiculo?.placa || "").toUpperCase(),
        renavam: body.veiculo?.renavam || "",
        chassi: (body.veiculo?.chassi || "").toUpperCase(),
        marca: body.veiculo?.marca || "",
        modelo: body.veiculo?.modelo || "",
        anoFab: body.veiculo?.anoFab || "",
        anoMod: body.veiculo?.anoMod || "",
        cor: body.veiculo?.cor || "",
        combustivel: body.veiculo?.combustivel || "",
        especie: body.veiculo?.especie || "Automóvel",
      },
      poderes: Array.isArray(body.poderes) ? body.poderes : [],
      evidencias: {
        documento: null,
        documentoTipo: null,
        biometria: null,
        biometriaScore: null,
        liveness: null,
        assinatura: null,
        ip: null,
        userAgent: null,
        geo: null,
      },
    };
    this.data.procuracoes.push(p);
    this.save();
    return p;
  }

  updateProcuracao(id, userId, patch) {
    const p = this.findProcuracao(id, userId);
    if (!p) return null;
    if (p.status === "assinada") {
      const err = new Error("Procuração já assinada não pode ser editada");
      err.status = 409;
      throw err;
    }
    if (patch.cliente) p.cliente = { ...p.cliente, ...patch.cliente };
    if (patch.veiculo) p.veiculo = { ...p.veiculo, ...patch.veiculo };
    if (patch.poderes) p.poderes = patch.poderes;
    if (patch.validadeDias !== undefined) p.validadeDias = Number(patch.validadeDias);
    if (patch.substabelecer !== undefined) p.substabelecer = !!patch.substabelecer;
    if (patch.whatsapp !== undefined) p.whatsapp = patch.whatsapp;
    if (patch.observacoes !== undefined) p.observacoes = patch.observacoes;
    p.updatedAt = new Date().toISOString();
    this.save();
    return p;
  }

  cancelProcuracao(id, userId) {
    const p = this.findProcuracao(id, userId);
    if (!p) return null;
    p.status = "cancelada";
    p.updatedAt = new Date().toISOString();
    pushHist(p, "Cancelado pelo despachante");
    this.save();
    return p;
  }

  duplicateProcuracao(id, userId) {
    const p = this.findProcuracao(id, userId);
    if (!p) return null;
    const copy = JSON.parse(JSON.stringify(p));
    copy.id = this.uid();
    copy.token = this.token();
    copy.codigo = this.codigo();
    copy.pin = genPin();
    copy.status = "aguardando";
    copy.signedAt = null;
    copy.createdAt = new Date().toISOString();
    copy.updatedAt = copy.createdAt;
    copy.evidencias = {
      documento: null,
      documentoTipo: null,
      biometria: null,
      biometriaScore: null,
      liveness: null,
      assinatura: null,
      ip: null,
      userAgent: null,
      geo: null,
    };
    copy.historico = [{ em: copy.createdAt, fato: "Duplicado a partir de " + p.codigo }];
    this.data.procuracoes.push(copy);
    this.save();
    return copy;
  }

  unlockPublic(token, cpf, pin) {
    const p = this.findByToken(token);
    if (!p) return null;
    const a = String(cpf || "").replace(/\D/g, "");
    const b = String(p.cliente.cpf || "").replace(/\D/g, "");
    if (a !== b || String(pin || "") !== String(p.pin || "")) {
      const err = new Error("CPF ou PIN não conferem");
      err.status = 403;
      throw err;
    }
    pushHist(p, "Cliente identificou-se com CPF e PIN");
    this.save();
    return p;
  }

  saveEvidenceFile(token, kind, dataUrl) {
    const p = this.findByToken(token);
    if (!p) return null;
    if (p.status === "assinada" || p.status === "cancelada") {
      const err = new Error("Esta procuração não aceita novos envios");
      err.status = 409;
      throw err;
    }
    const match = String(dataUrl || "").match(
      /^data:(image\/(png|jpeg|jpg|webp));base64,(.+)$/i
    );
    if (!match) {
      const err = new Error("Imagem inválida");
      err.status = 400;
      throw err;
    }
    const ext = match[2].toLowerCase() === "png" ? "png" : "jpg";
    const dir = path.join(UPLOADS, p.id);
    fs.mkdirSync(dir, { recursive: true });
    const filename = `${kind}.${ext}`;
    const abs = path.join(dir, filename);
    fs.writeFileSync(abs, Buffer.from(match[3], "base64"));
    const rel = `/uploads/${p.id}/${filename}`;
    p.evidencias[kind] = rel;
    p.updatedAt = new Date().toISOString();
    if (p.status === "aguardando") p.status = "em_andamento";
    this.save();
    return p;
  }

  finalize(token, meta = {}) {
    const p = this.findByToken(token);
    if (!p) return null;
    if (p.status === "assinada") return p;
    if (p.status === "cancelada") {
      const err = new Error("Procuração cancelada");
      err.status = 409;
      throw err;
    }
    const ev = p.evidencias;
    if (!ev.documento || !ev.biometria || !ev.assinatura) {
      const err = new Error(
        "Conclua documento, biometria e assinatura antes de finalizar"
      );
      err.status = 400;
      throw err;
    }
    ev.ip = meta.ip || null;
    ev.userAgent = meta.userAgent || null;
    ev.geo = meta.geo || null;
    ev.liveness = meta.liveness || ev.liveness;
    ev.biometriaScore = meta.biometriaScore ?? ev.biometriaScore;
    ev.documentoTipo = meta.documentoTipo || ev.documentoTipo;
    p.status = "assinada";
    p.signedAt = new Date().toISOString();
    p.updatedAt = p.signedAt;
    this.save();
    return p;
  }

  publicClientView(p, despachante) {
    return {
      token: p.token,
      status: p.status,
      codigo: p.status === "assinada" ? p.codigo : null,
      createdAt: p.createdAt,
      signedAt: p.signedAt,
      validadeDias: p.validadeDias,
      substabelecer: p.substabelecer,
      cliente: p.cliente,
      veiculo: p.veiculo,
      poderes: p.poderes,
      observacoes: p.observacoes,
      outorgado: despachante
        ? {
            nome: despachante.nome,
            empresa: despachante.empresa,
            cpf: despachante.cpf,
            rg: despachante.rg,
            profissao: despachante.profissao,
            registro: despachante.registro,
            cidade: despachante.cidade,
            uf: despachante.uf,
            endereco: despachante.endereco,
            numero: despachante.numero,
            bairro: despachante.bairro,
          }
        : null,
      evidencias: {
        temDocumento: !!p.evidencias.documento,
        temBiometria: !!p.evidencias.biometria,
        temAssinatura: !!p.evidencias.assinatura,
      },
    };
  }

  verificationView(p, despachante) {
    if (!p || p.status !== "assinada") return null;
    return {
      valido: true,
      codigo: p.codigo,
      signedAt: p.signedAt,
      validadeDias: p.validadeDias,
      validoAte: validadeAte(p.signedAt, p.validadeDias),
      outorgante: p.cliente.nome,
      outorganteCpf: maskCpf(p.cliente.cpf),
      outorgado: despachante?.nome || "",
      empresa: despachante?.empresa || "",
      veiculo: {
        placa: p.veiculo.placa,
        marca: p.veiculo.marca,
        modelo: p.veiculo.modelo,
      },
      poderes: p.poderes,
    };
  }
}

function genPin() {
  return String(Math.floor(1000 + Math.random() * 9000));
}

function pushHist(p, fato) {
  p.historico ||= [];
  p.historico.push({ em: new Date().toISOString(), fato });
}

function strongPass(s) {
  s = String(s || "");
  if (s.length < 8) return "Use ao menos 8 caracteres";
  if (!/[A-Za-z]/.test(s) || !/\d/.test(s)) return "Misture letras e números";
  if (s === "demo123" || s === "123456" || s === "12345678") return "Essa senha é pública demais";
  return "";
}

function validadeAte(signedAt, dias) {
  const d = new Date(signedAt);
  d.setDate(d.getDate() + Number(dias || 0));
  return d.toISOString();
}

function maskCpf(cpf) {
  const d = String(cpf || "").replace(/\D/g, "");
  if (d.length !== 11) return cpf || "";
  return `${d.slice(0, 3)}.***.***-${d.slice(9)}`;
}

function seed(store) {
  if (store.data.users.length) return;
  store.createUser({
    email: "despachante@outorga.app",
    password: "123456",
    nome: "Carlos Henrique Mendes",
    cpf: "084.219.763-50",
    rg: "2.104.883 SSP/CE",
    nacionalidade: "brasileiro",
    estadoCivil: "casado",
    profissao: "Despachante documentalista",
    empresa: "Mendes Documentos",
    registro: "SINDETRAN-CE 1847",
    telefone: "(88) 98812-4400",
    cep: "63010-010",
    endereco: "Rua São Pedro",
    numero: "520",
    bairro: "Centro",
    cidade: "Juazeiro do Norte",
    uf: "CE",
  });
}

const store = new Store();
seed(store);

module.exports = { store, UPLOADS };
