const PDFDocument = require("pdfkit");
const QRCode = require("qrcode");
const fs = require("fs");
const path = require("path");
const { PODERES_MAP } = require("./poderes");

function fmtDate(iso) {
  if (!iso) return "—";
  const d = new Date(iso);
  return d.toLocaleDateString("pt-BR", {
    day: "2-digit",
    month: "long",
    year: "numeric",
    timeZone: "America/Sao_Paulo",
  });
}

function fmtDateTime(iso) {
  if (!iso) return "—";
  const d = new Date(iso);
  return d.toLocaleString("pt-BR", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    timeZone: "America/Sao_Paulo",
  });
}

function validadeAte(signedAt, dias) {
  const d = new Date(signedAt || Date.now());
  d.setDate(d.getDate() + Number(dias || 0));
  return fmtDate(d.toISOString());
}

function qualifica(p) {
  const bits = [
    p.nome,
    p.nacionalidade,
    p.estadoCivil,
    p.profissao,
    p.cpf ? `inscrito(a) no CPF sob o nº ${p.cpf}` : null,
    p.rg ? `portador(a) do RG nº ${p.rg}${p.orgaoRg ? ` ${p.orgaoRg}` : ""}` : null,
  ].filter(Boolean);
  const end = [
    p.endereco,
    p.numero,
    p.complemento,
    p.bairro,
    p.cidade && p.uf ? `${p.cidade}/${p.uf}` : p.cidade || p.uf,
    p.cep ? `CEP ${p.cep}` : null,
  ]
    .filter(Boolean)
    .join(", ");
  let s = bits.join(", ");
  if (end) s += `, residente e domiciliado(a) à ${end}`;
  return s;
}

function contentWidth(doc) {
  return doc.page.width - 96;
}

function resetCursor(doc, y) {
  doc.x = 48;
  if (y != null) doc.y = y;
}

function drawHeader(doc, p) {
  doc.save();
  doc.rect(0, 0, doc.page.width, 78).fill("#1A2F23");
  doc.fillColor("#D4BC7D").font("Times-Bold").fontSize(11).text("OUTORGA", 48, 22, {
    characterSpacing: 3,
    width: 200,
    lineBreak: false,
  });
  doc
    .fillColor("#F6F0E6")
    .font("Times-Roman")
    .fontSize(9)
    .text("Instrumento particular de procuração  ·  Assinatura eletrônica avançada", 48, 42, {
      width: 340,
      lineBreak: false,
    });
  doc
    .fillColor("#F6F0E6")
    .font("Helvetica")
    .fontSize(7)
    .text("PROTOCOLO", doc.page.width - 200, 20, { width: 152, align: "right" });
  doc
    .fillColor("#D4BC7D")
    .font("Times-Bold")
    .fontSize(13)
    .text(p.codigo || "OUT-00000", doc.page.width - 200, 32, {
      width: 152,
      align: "right",
    });
  doc
    .fillColor("#F6F0E6")
    .font("Helvetica")
    .fontSize(7)
    .text("Verificação no QR Code", doc.page.width - 200, 50, {
      width: 152,
      align: "right",
    });
  doc.restore();
  resetCursor(doc, 96);
}

function drawFooter(doc, page, total) {
  const y = doc.page.height - 32;
  const margins = doc.page.margins;
  doc.page.margins = { top: 0, left: 0, right: 0, bottom: 0 };
  doc.save();
  doc.moveTo(48, y).lineTo(doc.page.width - 48, y).strokeColor("#D9CDB8").lineWidth(0.6).stroke();
  doc
    .fillColor("#7A6D5C")
    .font("Times-Italic")
    .fontSize(7.5)
    .text(
      "Assinatura eletrônica avançada com prova de vida e documento oficial — Lei 14.063/2020 e MP 2.200-2/2001.",
      48,
      y + 6,
      { width: 380, lineBreak: false }
    );
  doc
    .font("Helvetica")
    .fontSize(8)
    .text(`${page} / ${total}`, doc.page.width - 90, y + 6, { width: 42, align: "right", lineBreak: false });
  doc.restore();
  doc.page.margins = margins;
}

function paragraph(doc, text, opts = {}) {
  resetCursor(doc);
  doc
    .fillColor("#1C1410")
    .font(opts.bold ? "Times-Bold" : "Times-Roman")
    .fontSize(opts.size || 10.5)
    .text(text, 48, doc.y, {
      width: contentWidth(doc),
      align: opts.align || "justify",
      lineGap: 2.4,
      indent: opts.indent || 0,
    });
}

function sectionTitle(doc, n, title) {
  resetCursor(doc, doc.y + 12);
  doc.fillColor("#1A2F23").font("Times-Bold").fontSize(11.5).text(`${n}.  ${title.toUpperCase()}`, 48, doc.y, {
    width: contentWidth(doc),
  });
  doc
    .moveTo(48, doc.y + 2)
    .lineTo(doc.page.width - 48, doc.y + 2)
    .strokeColor("#C9A227")
    .lineWidth(0.8)
    .stroke();
  resetCursor(doc, doc.y + 10);
}

function safeImage(doc, relPath, x, y, w, h) {
  if (!relPath) return false;
  const abs = path.join(__dirname, "data", relPath.replace(/^\//, ""));
  if (!fs.existsSync(abs)) return false;
  try {
    const stat = fs.statSync(abs);
    if (stat.size < 80) return false;
    doc.save();
    doc.rect(x, y, w, h).clip();
    doc.image(abs, x, y, { fit: [w, h], align: "center", valign: "center" });
    doc.restore();
    doc.rect(x, y, w, h).strokeColor("#D9CDB8").lineWidth(0.6).stroke();
    return true;
  } catch {
    try {
      doc.restore();
    } catch {
      /* already restored */
    }
    return false;
  }
}

async function buildPdf(p, despachante, verifyUrl) {
  const qr = await QRCode.toDataURL(verifyUrl, {
    margin: 1,
    width: 220,
    color: { dark: "#1A2F23", light: "#FFFFFF" },
  });

  return new Promise((resolve, reject) => {
    const doc = new PDFDocument({
      size: "A4",
      bufferPages: true,
      margins: { top: 96, bottom: 56, left: 48, right: 48 },
      info: {
        Title: `Procuração ${p.codigo}`,
        Author: "OUTORGA",
        Subject: "Instrumento particular de procuração com assinatura eletrônica avançada",
      },
    });
    const chunks = [];
    doc.on("data", (c) => chunks.push(c));
    doc.on("end", () => resolve(Buffer.concat(chunks)));
    doc.on("error", reject);

    drawHeader(doc, p);

    doc
      .fillColor("#1A2F23")
      .font("Times-Bold")
      .fontSize(16)
      .text("INSTRUMENTO PARTICULAR DE PROCURAÇÃO", { align: "center" });
    doc
      .fillColor("#7A6D5C")
      .font("Times-Italic")
      .fontSize(10)
      .text("com poderes específicos para atos de trânsito e documentação veicular", {
        align: "center",
      });
    doc.moveDown(0.9);

    const outorgante = qualifica({ ...p.cliente });
    const outorgado = qualifica({
      nome: despachante.nome,
      nacionalidade: despachante.nacionalidade,
      estadoCivil: despachante.estadoCivil,
      profissao: despachante.profissao,
      cpf: despachante.cpf,
      rg: despachante.rg,
      endereco: despachante.endereco,
      numero: despachante.numero,
      bairro: despachante.bairro,
      cidade: despachante.cidade,
      uf: despachante.uf,
      cep: despachante.cep,
    });

    paragraph(
      doc,
      `Pelo presente instrumento particular de procuração, ${outorgante}, doravante denominado(a) OUTORGANTE, nomeia e constitui seu(sua) bastante procurador(a) ${outorgado}${
        despachante.empresa ? `, atuando sob a denominação ${despachante.empresa}` : ""
      }${
        despachante.registro ? `, registro profissional ${despachante.registro}` : ""
      }, doravante denominado(a) OUTORGADO(A), a quem confere os poderes adiante especificados, para o fiel e cabal cumprimento do presente mandato relativamente ao veículo abaixo descrito.`
    );

    sectionTitle(doc, "I", "Do veículo");
    const v = p.veiculo;
    const rows = [
      ["Placa", v.placa || "—", "RENAVAM", v.renavam || "—"],
      ["Chassi", v.chassi || "—", "Espécie", v.especie || "—"],
      [
        "Marca / modelo",
        [v.marca, v.modelo].filter(Boolean).join(" ") || "—",
        "Ano fab./mod.",
        [v.anoFab, v.anoMod].filter(Boolean).join(" / ") || "—",
      ],
      ["Cor", v.cor || "—", "Combustível", v.combustivel || "—"],
    ];
    const col = (doc.page.width - 96) / 4;
    const startX = 48;
    let y = doc.y;
    rows.forEach((r, i) => {
      const bg = i % 2 === 0 ? "#F6F0E6" : "#FFFFFF";
      doc.rect(startX, y, doc.page.width - 96, 22).fill(bg);
      doc.fillColor("#7A6D5C").font("Helvetica").fontSize(7).text(r[0].toUpperCase(), startX + 6, y + 4, {
        width: col - 8,
        lineBreak: false,
      });
      doc.fillColor("#1C1410").font("Times-Bold").fontSize(9.5).text(String(r[1]), startX + 6, y + 12, {
        width: col * 2 - 16,
        lineBreak: false,
      });
      doc.fillColor("#7A6D5C").font("Helvetica").fontSize(7).text(r[2].toUpperCase(), startX + col * 2 + 6, y + 4, {
        width: col - 8,
        lineBreak: false,
      });
      doc
        .fillColor("#1C1410")
        .font("Times-Bold")
        .fontSize(9.5)
        .text(String(r[3]), startX + col * 2 + 6, y + 12, { width: col * 2 - 14, lineBreak: false });
      y += 22;
    });
    resetCursor(doc, y + 8);

    sectionTitle(doc, "II", "Dos poderes");
    paragraph(
      doc,
      "O(A) OUTORGADO(A) fica especialmente autorizado(a) a praticar, em nome do(a) OUTORGANTE, os seguintes atos:"
    );
    doc.moveDown(0.3);
    const escolhidos = (p.poderes || [])
      .map((id) => PODERES_MAP[id])
      .filter(Boolean);
    if (!escolhidos.length) {
      paragraph(doc, "Nenhum poder específico foi selecionado.");
    } else {
      escolhidos.forEach((pod, idx) => {
        doc
          .fillColor("#1A2F23")
          .font("Times-Bold")
          .fontSize(10)
          .text(`${idx + 1}. ${pod.titulo}`);
        doc
          .fillColor("#1C1410")
          .font("Times-Roman")
          .fontSize(10)
          .text(pod.texto, { align: "justify", lineGap: 1.8 });
        doc.moveDown(0.28);
      });
    }
    if (p.substabelecer) {
      doc.moveDown(0.15);
      paragraph(
        doc,
        "Fica o(a) OUTORGADO(A) autorizado(a) a substabelecer, no todo ou em parte, os poderes ora conferidos, com ou sem reserva."
      );
    } else {
      doc.moveDown(0.15);
      paragraph(doc, "Fica vedado o substabelecimento dos poderes ora conferidos.");
    }

    if (p.observacoes) {
      sectionTitle(doc, "III", "Observações do mandato");
      paragraph(doc, p.observacoes);
    }

    sectionTitle(doc, p.observacoes ? "IV" : "III", "Da validade");
    const inicio = p.signedAt || p.createdAt;
    paragraph(
      doc,
      `Este mandato vigorará pelo prazo de ${p.validadeDias} (${extensoDias(
        p.validadeDias
      )}) dias, contados da assinatura eletrônica, com termo final em ${validadeAte(
        inicio,
        p.validadeDias
      )}, podendo ser revogado a qualquer tempo pelo(a) OUTORGANTE, mediante comunicação formal ao(à) OUTORGADO(A). Na omissão de prazo, observar-se-ia o limite de três anos.`
    );

    sectionTitle(doc, p.observacoes ? "V" : "IV", "Da assinatura eletrônica e da prova de vida");
    paragraph(
      doc,
      `O(A) OUTORGANTE declara, sob as penas da lei, que: (i) conferiu todos os dados pessoais e do veículo constantes deste instrumento; (ii) outorga consciente e livremente os poderes acima; (iii) submeteu-se a captura de documento oficial com foto e a biometria facial com prova de vida; (iv) apôs sua assinatura eletrônica avançada neste instrumento, nos termos da Lei nº 14.063/2020 e da Medida Provisória nº 2.200-2/2001. A autenticidade pode ser conferida pelo código ${p.codigo} ou pelo QR Code anexo.`
    );

    const cidade = p.cliente.cidade || despachante.cidade || "Juazeiro do Norte";
    const uf = p.cliente.uf || despachante.uf || "CE";
    if (doc.y > doc.page.height - 220) {
      doc.addPage();
      drawHeader(doc, p);
    } else {
      resetCursor(doc, doc.y + 10);
    }
    paragraph(
      doc,
      `${cidade}/${uf}, ${fmtDate(p.signedAt || new Date().toISOString())}.`,
      { align: "left" }
    );

    resetCursor(doc, doc.y + 10);
    const sigW = 240;
    const sigH = 70;
    const sigX = 48;
    const sigY = doc.y;
    if (p.evidencias.assinatura) {
      safeImage(doc, p.evidencias.assinatura, sigX, sigY, sigW, sigH);
    } else {
      doc.rect(sigX, sigY, sigW, sigH).strokeColor("#D9CDB8").stroke();
    }
    doc
      .moveTo(sigX, sigY + sigH + 8)
      .lineTo(sigX + sigW, sigY + sigH + 8)
      .strokeColor("#1C1410")
      .lineWidth(0.6)
      .stroke();
    doc
      .fillColor("#1C1410")
      .font("Times-Bold")
      .fontSize(9.5)
      .text(p.cliente.nome || "OUTORGANTE", sigX, sigY + sigH + 12, { width: sigW, align: "center" });
    doc
      .fillColor("#7A6D5C")
      .font("Times-Roman")
      .fontSize(8)
      .text(`CPF ${p.cliente.cpf || "—"}  ·  Assinatura eletrônica avançada`, sigX, sigY + sigH + 24, {
        width: sigW,
        align: "center",
      });

    const qrBuf = Buffer.from(qr.split(",")[1], "base64");
    const qrX = doc.page.width - 48 - 92;
    doc.image(qrBuf, qrX, sigY, { width: 84 });
    doc
      .fillColor("#7A6D5C")
      .font("Helvetica")
      .fontSize(7)
      .text("Verificar autenticidade", qrX, sigY + 86, { width: 84, align: "center" });

    doc.addPage();
    drawHeader(doc, p);
    resetCursor(doc, 96);

    doc
      .fillColor("#1A2F23")
      .font("Times-Bold")
      .fontSize(14)
      .text("ANEXO I — EVIDÊNCIAS DE IDENTIDADE E BIOMETRIA", { align: "center" });
    doc.moveDown(0.6);
    paragraph(
      doc,
      "As imagens abaixo integram este instrumento para fins de identificação do(a) outorgante, prova de vida e registro da assinatura eletrônica. O despachante documentalista declara ter recebido o presente mandato após a conclusão do fluxo digital."
    );
    doc.moveDown(0.7);

    const boxW = 230;
    const boxH = 160;
    const left = 48;
    const right = doc.page.width - 48 - boxW;

    doc.fillColor("#7A6D5C").font("Helvetica").fontSize(8).text("DOCUMENTO DE IDENTIFICAÇÃO", left, doc.y);
    const imgY = doc.y + 12;
    if (!safeImage(doc, p.evidencias.documento, left, imgY, boxW, boxH)) {
      doc.rect(left, imgY, boxW, boxH).strokeColor("#D9CDB8").stroke();
      doc.fillColor("#A89880").font("Times-Italic").fontSize(9).text("Não anexado", left, imgY + 74, {
        width: boxW,
        align: "center",
      });
    }
    doc
      .fillColor("#7A6D5C")
      .font("Helvetica")
      .fontSize(8)
      .text("BIOMETRIA FACIAL (PROVA DE VIDA)", right, imgY - 12);
    if (!safeImage(doc, p.evidencias.biometria, right, imgY, boxW, boxH)) {
      doc.rect(right, imgY, boxW, boxH).strokeColor("#D9CDB8").stroke();
    }

    doc.y = imgY + boxH + 18;
    doc.fillColor("#7A6D5C").font("Helvetica").fontSize(8).text("ASSINATURA CAPTURADA", left);
    const sig2Y = doc.y + 10;
    if (!safeImage(doc, p.evidencias.assinatura, left, sig2Y, boxW, 90)) {
      doc.rect(left, sig2Y, boxW, 90).strokeColor("#D9CDB8").stroke();
    }

    doc.y = sig2Y;
    const metaX = right;
    doc.fillColor("#1A2F23").font("Times-Bold").fontSize(10).text("Registro técnico", metaX, doc.y, {
      width: boxW,
    });
    const metas = [
      ["Código", p.codigo],
      ["Assinado em", fmtDateTime(p.signedAt)],
      ["Válido até", validadeAte(p.signedAt, p.validadeDias)],
      ["Documento", p.evidencias.documentoTipo || "CNH / RG / identidade"],
      ["Prova de vida", p.evidencias.liveness || "Captura facial com desafio"],
      [
        "Similaridade",
        p.evidencias.biometriaScore != null
          ? `${Math.round(Number(p.evidencias.biometriaScore))}%`
          : "Avaliada no fluxo",
      ],
      ["IP de origem", p.evidencias.ip || "—"],
      ["Dispositivo", truncate(p.evidencias.userAgent || "—", 72)],
    ];
    let my = doc.y + 6;
    metas.forEach(([k, val]) => {
      doc.fillColor("#7A6D5C").font("Helvetica").fontSize(7).text(k.toUpperCase(), metaX, my, {
        width: boxW,
      });
      doc
        .fillColor("#1C1410")
        .font("Times-Roman")
        .fontSize(9)
        .text(String(val), metaX, my + 9, { width: boxW });
      my += 24;
    });

    resetCursor(doc, Math.max(sig2Y + 110, my + 8));
    paragraph(
      doc,
      "A aceitação deste instrumento perante órgãos de trânsito observa a regulamentação local. Quando o órgão exigir firma reconhecida por autenticidade ou assinatura ICP-Brasil, o despachante deverá complementar o rito. Este documento constitui assinatura eletrônica avançada com prova de vida e batimento documental."
    );

    const range = doc.bufferedPageRange();
    for (let i = range.start; i < range.start + range.count; i++) {
      doc.switchToPage(i);
      drawFooter(doc, i - range.start + 1, range.count);
    }

    doc.end();
  });
}

function truncate(s, n) {
  s = String(s);
  return s.length > n ? s.slice(0, n - 1) + "…" : s;
}

function extensoDias(n) {
  const map = {
    30: "trinta",
    60: "sessenta",
    90: "noventa",
    180: "cento e oitenta",
    365: "trezentos e sessenta e cinco",
    730: "setecentos e trinta",
    1095: "mil e noventa e cinco",
  };
  return map[Number(n)] || String(n);
}

module.exports = { buildPdf, fmtDate, fmtDateTime, validadeAte, qualifica };
