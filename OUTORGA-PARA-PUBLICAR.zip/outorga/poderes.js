const PODERES = [
  {
    id: "representar",
    titulo: "Representação junto aos órgãos de trânsito",
    texto:
      "Representar o(a) outorgante junto ao DETRAN, SENATRAN, CIRETRAN, CIRP, órgãos de trânsito, cartórios, instituições financeiras, seguradoras e demais repartições públicas federais, estaduais e municipais, autarquias e sociedades de economia mista, podendo protocolar, acompanhar, retirar e assinar requerimentos, termos, declarações e formulários.",
  },
  {
    id: "licenciamento",
    titulo: "Licenciamento anual e emissão de CRLV-e",
    texto:
      "Requerer e obter o licenciamento anual do veículo, emitir e retirar o CRLV-e, quitar taxas de licenciamento e praticar os atos correlatos.",
  },
  {
    id: "transferencia",
    titulo: "Transferência de propriedade (CRV / ATPV-e)",
    texto:
      "Assinar e entregar o Certificado de Registro de Veículo (CRV) e/ou a Autorização para Transferência de Propriedade do Veículo (ATPV-e), preencher e assinar recibos de transferência, transmitir domínio, direito, ação e posse, inclusive para si ou para terceiros.",
  },
  {
    id: "emplacamento",
    titulo: "Primeiro emplacamento",
    texto:
      "Solicitar o primeiro emplacamento, registrar o veículo em nome do(a) outorgante ou de terceiro, obter placas e documentos iniciais.",
  },
  {
    id: "segunda_via",
    titulo: "2ª via de CRV, CRLV e demais documentos",
    texto:
      "Requerer e retirar 1ª ou 2ª via do CRV, CRLV, DUT e quaisquer outros documentos do veículo.",
  },
  {
    id: "vistoria",
    titulo: "Vistoria veicular",
    texto:
      "Agendar, autorizar, acompanhar e assinar vistorias veiculares, inspeções e laudos, inclusive de identificação e de segurança.",
  },
  {
    id: "alteracao",
    titulo: "Alteração de dados e características",
    texto:
      "Requerer alteração de dados cadastrais, de característica, de cor, de combustível, de categoria e demais modificações regulamentares do veículo.",
  },
  {
    id: "gravame",
    titulo: "Baixa de gravame e alienação fiduciária",
    texto:
      "Requerer baixa de gravame, desalienação, carta de quitação, desbloqueio e retirada de restrição financeira ou administrativa.",
  },
  {
    id: "debitos",
    titulo: "Regularização de débitos (IPVA, taxas e multas)",
    texto:
      "Consultar, parcelar e quitar IPVA, seguro obrigatório, taxas, multas e demais débitos, dando e recebendo quitação.",
  },
  {
    id: "recursos",
    titulo: "Defesa e recurso de multas",
    texto:
      "Apresentar defesa prévia, recurso de multa e representação em processos administrativos de trânsito, juntar documentos e acompanhar decisões.",
  },
  {
    id: "apreensao",
    titulo: "Liberação de veículo apreendido",
    texto:
      "Requerer a liberação e retirada do veículo de pátio, depósito, DVA, delegacia ou qualquer recinto, regularizando pendências necessárias.",
  },
  {
    id: "baixa",
    titulo: "Baixa definitiva / desmonte / comunicação de venda",
    texto:
      "Requerer baixa definitiva, desmonte, recadastramento, reativação e comunicação de venda do veículo.",
  },
  {
    id: "bloqueios",
    titulo: "Retirada de bloqueios e restrições",
    texto:
      "Requerer desbloqueio, baixa de roubo e furto, retirada de restrição judicial, administrativa ou cautelar, quando cabível.",
  },
  {
    id: "declaracoes",
    titulo: "Declarações, termos e residência",
    texto:
      "Assinar termos, declarações, declaração de residência, nada-consta e demais instrumentos exigidos para o fiel cumprimento do mandato.",
  },
];

const PODERES_MAP = Object.fromEntries(PODERES.map((p) => [p.id, p]));

module.exports = { PODERES, PODERES_MAP };
