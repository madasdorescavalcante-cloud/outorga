const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];

const api = {
  async req(path, opts = {}) {
    const res = await fetch(path, {
      credentials: "same-origin",
      headers: { "Content-Type": "application/json", ...(opts.headers || {}) },
      ...opts,
      body: opts.body && typeof opts.body !== "string" ? JSON.stringify(opts.body) : opts.body,
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || "Falha na requisição");
    return data;
  },
  me: () => api.req("/api/me"),
  login: (body) => api.req("/api/auth/login", { method: "POST", body }),
  register: (body) => api.req("/api/auth/register", { method: "POST", body }),
  logout: () => api.req("/api/auth/logout", { method: "POST", body: {} }),
};

function toast(msg) {
  let el = $(".toast");
  if (!el) {
    el = document.createElement("div");
    el.className = "toast";
    document.body.appendChild(el);
  }
  el.textContent = msg;
  el.classList.add("show");
  clearTimeout(el._t);
  el._t = setTimeout(() => el.classList.remove("show"), 2600);
}

function showErr(el, msg) {
  if (!el) return;
  el.textContent = msg;
  el.classList.toggle("show", !!msg);
}

function onlyDigits(s) {
  return String(s || "").replace(/\D/g, "");
}

function maskCPF(v) {
  v = onlyDigits(v).slice(0, 11);
  return v
    .replace(/(\d{3})(\d)/, "$1.$2")
    .replace(/(\d{3})(\d)/, "$1.$2")
    .replace(/(\d{3})(\d{1,2})$/, "$1-$2");
}

function maskPhone(v) {
  v = onlyDigits(v).slice(0, 11);
  if (v.length <= 10) return v.replace(/(\d{2})(\d{4})(\d{0,4})/, "($1) $2-$3").replace(/-$/, "");
  return v.replace(/(\d{2})(\d{5})(\d{0,4})/, "($1) $2-$3").replace(/-$/, "");
}

function maskCEP(v) {
  v = onlyDigits(v).slice(0, 8);
  return v.replace(/(\d{5})(\d{1,3})/, "$1-$2");
}

function maskPlate(v) {
  return String(v || "")
    .toUpperCase()
    .replace(/[^A-Z0-9]/g, "")
    .slice(0, 7);
}

function validCPF(cpf) {
  const s = onlyDigits(cpf);
  if (s.length !== 11 || /^(\d)\1+$/.test(s)) return false;
  let sum = 0;
  for (let i = 0; i < 9; i++) sum += +s[i] * (10 - i);
  let d = (sum * 10) % 11;
  if (d === 10) d = 0;
  if (d !== +s[9]) return false;
  sum = 0;
  for (let i = 0; i < 10; i++) sum += +s[i] * (11 - i);
  d = (sum * 10) % 11;
  if (d === 10) d = 0;
  return d === +s[10];
}

function bindMasks(root = document) {
  $$("[data-mask]", root).forEach((input) => {
    const type = input.dataset.mask;
    const apply = () => {
      if (type === "cpf") input.value = maskCPF(input.value);
      if (type === "phone") input.value = maskPhone(input.value);
      if (type === "cep") input.value = maskCEP(input.value);
      if (type === "placa") input.value = maskPlate(input.value);
    };
    input.addEventListener("input", apply);
    apply();
  });
}

async function viaCEP(cep, map) {
  const d = onlyDigits(cep);
  if (d.length !== 8) return;
  const r = await fetch(`https://viacep.com.br/ws/${d}/json/`);
  const j = await r.json();
  if (j.erro) return;
  if (map.endereco) map.endereco.value = j.logradouro || map.endereco.value;
  if (map.bairro) map.bairro.value = j.bairro || map.bairro.value;
  if (map.cidade) map.cidade.value = j.localidade || map.cidade.value;
  if (map.uf) map.uf.value = j.uf || map.uf.value;
}

function fmtDate(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleString("pt-BR", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    timeZone: "America/Sao_Paulo",
  });
}

function statusBadge(status) {
  const map = {
    aguardando: ["b-wait", "Aguardando assinatura"],
    em_andamento: ["b-run", "Em andamento"],
    assinada: ["b-ok", "Assinada"],
    cancelada: ["b-off", "Cancelada"],
  };
  const [cls, label] = map[status] || ["b-off", status];
  return `<span class="badge ${cls}">${label}</span>`;
}

function initials(name) {
  return String(name || "?")
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((p) => p[0])
    .join("")
    .toUpperCase();
}

function compressImage(dataUrl, max = 1280, quality = 0.78) {
  return new Promise((resolve) => {
    const img = new Image();
    img.onload = () => {
      let { width, height } = img;
      if (width > max || height > max) {
        const r = Math.min(max / width, max / height);
        width = Math.round(width * r);
        height = Math.round(height * r);
      }
      const c = document.createElement("canvas");
      c.width = width;
      c.height = height;
      c.getContext("2d").drawImage(img, 0, 0, width, height);
      resolve(c.toDataURL("image/jpeg", quality));
    };
    img.onerror = () => resolve(dataUrl);
    img.src = dataUrl;
  });
}

function fileToDataUrl(file) {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(r.result);
    r.onerror = reject;
    r.readAsDataURL(file);
  });
}

async function requireSession() {
  try {
    const { user } = await api.me();
    if (user.mustChangePassword && !location.pathname.startsWith("/conta")) {
      location.href = "/conta";
      return null;
    }
    return user;
  } catch {
    location.href = "/";
    return null;
  }
}

function mountTopbar(user, current) {
  const bar = $(".topbar");
  if (!bar) return;
  bar.innerHTML = `
    <a class="mark" href="/painel">
      <div class="mark-seal">O</div>
      <span>Outorga</span>
    </a>
    <nav class="top-nav">
      <a href="/painel" class="${current === "painel" ? "on" : ""}">Painel</a>
      <a href="/nova" class="${current === "nova" ? "on" : ""}">Nova procuração</a>
      <a href="/conta" class="${current === "conta" ? "on" : ""}">Meus dados</a>
    </nav>
    <div class="user-pill">
      <div>
        <div style="font-weight:600">${user.nome.split(" ")[0]}</div>
        <div style="opacity:.7;font-size:12px">${user.empresa || "Despachante"}</div>
      </div>
      <div class="avatar">${initials(user.nome)}</div>
    </div>
  `;
}

function waLink(phone, text) {
  const n = onlyDigits(phone);
  const full = n.length <= 11 ? `55${n}` : n;
  return `https://wa.me/${full}?text=${encodeURIComponent(text)}`;
}
