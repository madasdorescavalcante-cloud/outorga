const path = require("path");
const express = require("express");
const session = require("express-session");
const bcrypt = require("bcryptjs");
const { store, UPLOADS } = require("./store");
const { PODERES } = require("./poderes");
const { buildPdf } = require("./pdf");

const app = express();
const PORT = process.env.PORT || 3000;

app.set("trust proxy", 1);
app.disable("x-powered-by");

app.use((req, res, next) => {
  res.setHeader("Content-Security-Policy", "frame-ancestors *");
  res.setHeader("Access-Control-Allow-Origin", req.get("origin") || "*");
  res.setHeader("Access-Control-Allow-Credentials", "true");
  next();
});

app.use(
  session({
    name: "outorga.sid",
    secret: process.env.SESSION_SECRET || "outorga-demo-secret-change-me",
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      sameSite: "lax",
      secure: false,
      maxAge: 1000 * 60 * 60 * 24 * 7,
    },
  })
);

app.use(express.json({ limit: "12mb" }));
app.use(express.urlencoded({ extended: true, limit: "12mb" }));

app.use("/uploads", express.static(UPLOADS, { maxAge: "1d" }));
app.use(express.static(path.join(__dirname, "public")));

function requireAuth(req, res, next) {
  if (!req.session.userId) {
    return res.status(401).json({ error: "Não autenticado" });
  }
  const user = store.findUser(req.session.userId);
  if (!user) {
    req.session.destroy(() => {});
    return res.status(401).json({ error: "Sessão inválida" });
  }
  req.user = user;
  next();
}

function publicOrigin(req) {
  const proto = (req.get("x-forwarded-proto") || req.protocol || "https").split(",")[0];
  const host = req.get("x-forwarded-host") || req.get("host");
  return `${proto}://${host}`;
}

function clientIp(req) {
  return (
    (req.get("x-forwarded-for") || "").split(",")[0].trim() ||
    req.ip ||
    req.connection?.remoteAddress ||
    ""
  );
}

app.get("/api/poderes", (_req, res) => {
  res.json(PODERES);
});

app.post("/api/auth/register", (req, res) => {
  try {
    const { email, password, nome } = req.body || {};
    if (!email || !password || !nome) {
      return res.status(400).json({ error: "Informe nome, e-mail e senha" });
    }
    if (String(password).length < 8 || !/[A-Za-z]/.test(password) || !/\d/.test(password)) {
      return res.status(400).json({ error: "Senha deve ter ao menos 8 caracteres, com letras e números" });
    }
    const user = store.createUser(req.body);
    req.session.userId = user.id;
    res.json({ user });
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message });
  }
});

app.post("/api/auth/login", (req, res) => {
  const { email, password } = req.body || {};
  const user = store.findUserByEmail(email);
  if (!user || !bcrypt.compareSync(password || "", user.passwordHash)) {
    return res.status(401).json({ error: "E-mail ou senha inválidos" });
  }
  req.session.userId = user.id;
  res.json({ user: store.publicUser(user) });
});

app.post("/api/auth/logout", (req, res) => {
  req.session.destroy(() => res.json({ ok: true }));
});

app.get("/api/me", requireAuth, (req, res) => {
  res.json({ user: store.publicUser(req.user) });
});

app.put("/api/me", requireAuth, (req, res) => {
  const user = store.updateUser(req.user.id, req.body || {});
  res.json({ user });
});

app.put("/api/me/senha", requireAuth, (req, res) => {
  try {
    const user = store.changePassword(req.user.id, req.body?.atual, req.body?.nova);
    res.json({ user });
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message });
  }
});

app.get("/api/procuracoes", requireAuth, (req, res) => {
  const list = store.listProcuracoes(req.user.id).map((p) => ({
    id: p.id,
    token: p.token,
    codigo: p.codigo,
    status: p.status,
    createdAt: p.createdAt,
    signedAt: p.signedAt,
    validadeDias: p.validadeDias,
    cliente: { nome: p.cliente.nome, cpf: p.cliente.cpf, telefone: p.cliente.telefone },
    veiculo: { placa: p.veiculo.placa, marca: p.veiculo.marca, modelo: p.veiculo.modelo },
    poderes: p.poderes,
    link: `${publicOrigin(req)}/assinar/${p.token}`,
  }));
  res.json({ procuracoes: list });
});

app.post("/api/procuracoes", requireAuth, (req, res) => {
  const body = req.body || {};
  if (!body.cliente?.nome || !body.cliente?.cpf) {
    return res.status(400).json({ error: "Informe nome e CPF do cliente" });
  }
  if (!body.veiculo?.placa) {
    return res.status(400).json({ error: "Informe a placa do veículo" });
  }
  if (!Array.isArray(body.poderes) || !body.poderes.length) {
    return res.status(400).json({ error: "Selecione ao menos um poder" });
  }
  const p = store.createProcuracao(req.user.id, body);
  res.status(201).json({
    procuracao: p,
    link: `${publicOrigin(req)}/assinar/${p.token}`,
  });
});

app.get("/api/procuracoes/:id", requireAuth, (req, res) => {
  const p = store.findProcuracao(req.params.id, req.user.id);
  if (!p) return res.status(404).json({ error: "Não encontrada" });
  res.json({
    procuracao: p,
    link: `${publicOrigin(req)}/assinar/${p.token}`,
    verify: `${publicOrigin(req)}/verificar/${p.codigo}`,
  });
});

app.put("/api/procuracoes/:id", requireAuth, (req, res) => {
  try {
    const p = store.updateProcuracao(req.params.id, req.user.id, req.body || {});
    if (!p) return res.status(404).json({ error: "Não encontrada" });
    res.json({ procuracao: p });
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message });
  }
});

app.post("/api/procuracoes/:id/cancelar", requireAuth, (req, res) => {
  const p = store.cancelProcuracao(req.params.id, req.user.id);
  if (!p) return res.status(404).json({ error: "Não encontrada" });
  res.json({ procuracao: p });
});

app.post("/api/procuracoes/:id/duplicar", requireAuth, (req, res) => {
  const p = store.duplicateProcuracao(req.params.id, req.user.id);
  if (!p) return res.status(404).json({ error: "Não encontrada" });
  res.json({
    procuracao: p,
    link: `${publicOrigin(req)}/assinar/${p.token}`,
  });
});

app.get("/api/procuracoes/:id/pdf", requireAuth, async (req, res) => {
  const p = store.findProcuracao(req.params.id, req.user.id);
  if (!p) return res.status(404).json({ error: "Não encontrada" });
  if (p.status !== "assinada") {
    return res.status(409).json({ error: "A procuração ainda não foi assinada" });
  }
  try {
    const verify = `${publicOrigin(req)}/verificar/${p.codigo}`;
    const buf = await buildPdf(p, req.user, verify);
    const placa = (p.veiculo.placa || "veiculo").replace(/\s+/g, "");
    res.setHeader("Content-Type", "application/pdf");
    res.setHeader(
      "Content-Disposition",
      `attachment; filename="procuracao-${placa}-${p.codigo}.pdf"`
    );
    res.send(buf);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Falha ao gerar PDF" });
  }
});

app.get("/api/publico/:token", (req, res) => {
  const p = store.findByToken(req.params.token);
  if (!p) return res.status(404).json({ error: "Link inválido ou expirado" });
  if (p.status === "assinada") {
    const desp = store.findUser(p.userId);
    return res.json({
      precisaDesbloqueio: false,
      status: p.status,
      procuracao: store.publicClientView(p, desp),
    });
  }
  res.json({
    precisaDesbloqueio: true,
    status: p.status,
    outorganteHint: (p.cliente.nome || "").split(" ")[0],
  });
});

app.post("/api/publico/:token/desbloquear", (req, res) => {
  try {
    const p = store.unlockPublic(req.params.token, req.body?.cpf, req.body?.pin);
    if (!p) return res.status(404).json({ error: "Link inválido" });
    const desp = store.findUser(p.userId);
    res.json({ procuracao: store.publicClientView(p, desp) });
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message });
  }
});

app.post("/api/publico/:token/documento", (req, res) => {
  try {
    const p = store.saveEvidenceFile(req.params.token, "documento", req.body?.imagem);
    if (!p) return res.status(404).json({ error: "Link inválido" });
    if (req.body?.tipo) p.evidencias.documentoTipo = req.body.tipo;
    store.save();
    res.json({ ok: true });
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message });
  }
});

app.post("/api/publico/:token/biometria", (req, res) => {
  try {
    const p = store.saveEvidenceFile(req.params.token, "biometria", req.body?.imagem);
    if (!p) return res.status(404).json({ error: "Link inválido" });
    if (req.body?.score != null) p.evidencias.biometriaScore = req.body.score;
    if (req.body?.liveness) p.evidencias.liveness = req.body.liveness;
    store.save();
    res.json({ ok: true });
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message });
  }
});

app.post("/api/publico/:token/assinatura", (req, res) => {
  try {
    const p = store.saveEvidenceFile(req.params.token, "assinatura", req.body?.imagem);
    if (!p) return res.status(404).json({ error: "Link inválido" });
    res.json({ ok: true });
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message });
  }
});

app.post("/api/publico/:token/finalizar", (req, res) => {
  try {
    const p = store.finalize(req.params.token, {
      ip: clientIp(req),
      userAgent: req.get("user-agent"),
      geo: req.body?.geo || null,
      liveness: req.body?.liveness,
      biometriaScore: req.body?.biometriaScore,
      documentoTipo: req.body?.documentoTipo,
    });
    if (!p) return res.status(404).json({ error: "Link inválido" });
    res.json({
      ok: true,
      codigo: p.codigo,
      signedAt: p.signedAt,
    });
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message });
  }
});

app.get("/api/verificar/:codigo", (req, res) => {
  const p = store.findByCodigo(req.params.codigo);
  if (!p || p.status !== "assinada") {
    return res.json({ valido: false });
  }
  const desp = store.findUser(p.userId);
  res.json(store.verificationView(p, desp));
});

function sendPage(name) {
  return (_req, res) => {
    res.sendFile(path.join(__dirname, "public", name));
  };
}

app.get("/painel", sendPage("painel.html"));
app.get("/nova", sendPage("nova.html"));
app.get("/conta", sendPage("conta.html"));
app.get("/p/:id", sendPage("detalhe.html"));
app.get("/assinar/:token", sendPage("assinar.html"));
app.get("/verificar/:codigo", sendPage("verificar.html"));

app.get("*", (req, res, next) => {
  if (req.path.startsWith("/api/")) return res.status(404).json({ error: "Não encontrado" });
  next();
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`OUTORGA ouvindo em http://0.0.0.0:${PORT}`);
});
