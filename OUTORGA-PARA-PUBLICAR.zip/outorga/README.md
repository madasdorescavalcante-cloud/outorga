# OUTORGA

Procuração digital com biometria facial para despachantes documentalistas.

O despachante preenche veículo, poderes e dados do cliente e envia um link.
O cliente revisa o mandato, anexa CNH/RG, faz prova de vida e assina no celular.
O painel recebe a confirmação e gera o PDF para impressão, com QR de verificação.

## Como rodar

```bash
cd outorga
npm install
npm start
```

Abre em `http://localhost:3000`.

### Conta de demonstração

- E-mail: `despachante@outorga.app`
- Senha: `demo123`

Complete os dados do outorgado em **Meus dados** se for uma conta nova.

## Fluxo

1. Painel → Nova procuração
2. Copiar o link ou mandar no WhatsApp
3. Cliente: revisar → documento → biometria → assinar → confirmar
4. Painel: status **Assinada** → Baixar PDF

## Aviso jurídico

O PDF é um instrumento particular com **assinatura eletrônica avançada**
(Lei 14.063/2020 e MP 2.200-2/2001), prova de vida e documento com foto.

Alguns DETRANs ainda exigem firma reconhecida por autenticidade ou
certificado ICP-Brasil para atos específicos (especialmente transferência).
Confira a norma do órgão do estado antes de protocolar.
